#ifndef _UART_H
#define _UART_H
 
extern void UART_Init (void);


#endif //_UART_H
