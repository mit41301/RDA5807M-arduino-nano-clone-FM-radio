#ifndef HW_CONFIG_H
#define HW_CONFIG_H

/* PWM output for TDA7052A volume control */
#define PIN_PWM			2

#endif
