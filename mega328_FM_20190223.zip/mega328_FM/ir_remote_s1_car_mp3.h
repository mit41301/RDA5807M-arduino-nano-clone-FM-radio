#ifndef IR_REMOTE_S1_CAR_MP3_H
#define IR_REMOTE_S1_CAR_MP3_H


#include "commands.h"
#include <stdint.h>


enum Command ir_translate(uint8_t address, uint8_t code);


#endif